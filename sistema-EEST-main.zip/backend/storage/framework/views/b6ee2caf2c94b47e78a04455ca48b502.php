<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Asistencia — <?php echo e($curso); ?> — <?php echo e($fecha); ?></title>
  <style>
    * { box-sizing: border-box; }
    body { font-family: Arial, Helvetica, sans-serif; color: #111; margin: 24px; }
    .membrete { text-align: center; margin-bottom: 4px; }
    .membrete h1 { font-size: 20px; margin: 0; }
    .membrete p { font-size: 12px; color: #444; margin: 2px 0 0; }
    .meta { display: flex; justify-content: space-between; font-size: 13px; margin: 16px 0 12px; }
    table { border-collapse: collapse; width: 100%; }
    th, td { border: 1px solid #333; padding: 7px 9px; font-size: 13px; text-align: left; }
    thead th { background: #0b3d91; color: #fff; }
    td.num, th.num { width: 36px; text-align: center; }
    td.pa { width: 44px; text-align: center; }
    td.firma { width: 160px; }
    .no-print { margin: 0 0 16px; }
    .no-print button { font-size: 14px; padding: 8px 18px; border-radius: 8px; border: 1px solid #999; background: #fff; cursor: pointer; }
    @media print { body { margin: 10mm; } .no-print { display: none; } }
  </style>
</head>
<body>
  <div class="membrete">
    <h1>E.E.S.T N° 2 — Sistema Escolar</h1>
    <p>Planilla de asistencia · <?php echo e($curso); ?> · <?php echo e($fecha); ?><?php echo e($numero ? ' · Clase N° '.$numero : ''); ?><?php echo e($estado && $estado !== 'dictada' ? ' · '.ucfirst($estado) : ''); ?></p>
  </div>
  <div class="no-print"><button onclick="window.print()">Imprimir</button></div>
  <table>
    <thead>
      <tr><th class="num">N°</th><th>Apellido</th><th>Nombre</th><th>DNI</th><th class="pa">P</th><th class="pa">A</th><th>Nota</th><th>Firma</th></tr>
    </thead>
    <tbody>
      <?php $__empty_1 = true; $__currentLoopData = $filas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php $esP = in_array($f->estado, ['presente', 'tarde'], true); ?>
        <tr>
          <td class="num"><?php echo e($i + 1); ?></td>
          <td><?php echo e($f->apellido); ?></td>
          <td><?php echo e($f->nombre); ?></td>
          <td><?php echo e($f->dni); ?></td>
          <td class="pa"><?php echo e($esP ? 'X' : ''); ?></td>
          <td class="pa"><?php echo e($esP ? '' : 'X'); ?></td>
          <td><?php echo e($f->anotacion); ?></td>
          <td class="firma"></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="8">Sin registros en esta clase.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</body>
</html>
<?php /**PATH C:\laragon\www\Sistema-ENRO-main\backend\resources\views/asistencia/planilla.blade.php ENDPATH**/ ?>